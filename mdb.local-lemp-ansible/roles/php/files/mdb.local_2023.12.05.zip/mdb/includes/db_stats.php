<?php

require __DIR__ . '/mysql_config.php';
$link = mysqli_connect( $m_server, $m_user, $m_password, $m_database );
if ($link == false){
  print("error: " . mysqli_connect_error());
  die;
}

mysqli_set_charset($link, "utf8mb4");

$sql = "SELECT count(`name`) FROM `movies`;";
$result = mysqli_query( $link, $sql );
$num = mysqli_fetch_all($result, MYSQLI_NUM);
echo "<i>Всього записів:  ".$num[0][0]."</i>";

$sql = "SELECT count(`name`) FROM `movies` where watched='1';";
$result = mysqli_query( $link, $sql );
$num = mysqli_fetch_all($result, MYSQLI_NUM);
echo "<br/><br/><i>Всього переглянув:  ".$num[0][0]." , з яких:</i>";

$sql = "SELECT count(`name`) FROM `movies` where watched='1' and myrating>'6';";
$result = mysqli_query( $link, $sql );
$num = mysqli_fetch_all($result, MYSQLI_NUM);
echo "<br/><i>сподобалися:  ".$num[0][0]." , </i>";

echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
$sql = "SELECT count(`name`) FROM `movies` where watched='1' and myrating<'7';";
$result = mysqli_query( $link, $sql );
$num = mysqli_fetch_all($result, MYSQLI_NUM);
echo "<i>не сподобалися:  ".$num[0][0]."</i>";

$sql = "SELECT count(`name`) FROM `movies` where watched='0';";
$result = mysqli_query( $link, $sql );
$num = mysqli_fetch_all($result, MYSQLI_NUM);
echo "<br/><br/><i>Не переглядав:  ".$num[0][0]."</i>";

$sql = "SELECT count(`name`) FROM `movies` where myrating='0';";
$result = mysqli_query( $link, $sql );
$num = mysqli_fetch_all($result, MYSQLI_NUM);
echo "<br/><br/><i>З нульовим рейтингом:  ".$num[0][0]."</i>";

$sql = "SELECT count(`name`) FROM `movies` where `IMDB_rated`='0';";
$result = mysqli_query( $link, $sql );
$num = mysqli_fetch_all($result, MYSQLI_NUM);
echo "<br/><br/><i>Не оцінений на IMDB:  ".$num[0][0]."</i>";

$sql = "SELECT count(`name`) FROM `movies` where `story`='';";
$result = mysqli_query( $link, $sql );
$num = mysqli_fetch_all($result, MYSQLI_NUM);
echo "<br/><br/><i>З незаповненим сюжетом:  ".$num[0][0]."</i>";

$sql = "SELECT count(`name`) FROM `movies` where `story`!='' and `IMDB_rated`<>'0';";
$result = mysqli_query( $link, $sql );
$num = mysqli_fetch_all($result, MYSQLI_NUM);
echo "<br/><br/><i>Із заповненим сюжетом та виставленим рейтингом IMDB:  ".$num[0][0]."</i>";

mysqli_free_result($result);
mysqli_close($link);
?>

