<!DOCTYPE html>
<html>
<head>
  <script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="../js/script.js"></script>
  <link rel="stylesheet" type="text/css" href="../js/datatables.min.css"/>
  <script type="text/javascript" src="../js/datatables.min.js"></script>
</head>
<body>

<?php
  require __DIR__ . '/mysql_config.php';
  require __DIR__ . '/functions.php';
?>

<style type="text/css">
<?php include __DIR__ . '/style.css'; ?>
</style>

<?php
  $link = mysqli_connect( $m_server, $m_user, $m_password, $m_database );
  if ($link == false){
    print("error: " . mysqli_connect_error());
    die;
  }

$need_limit = "";
mysqli_set_charset($link, "utf8mb4");

$sql = "select `name`,`year`,`codec`,`resolution`,`watched`,`myrating`,`IMDB_rating`,`IMDB_voices`,`IMDB_link`,`IMDB_rated`,`tracker`,`tracker_link`,`path`,`genres`,`story` from `movies` where 1";
if($debug == "1"){ echo "Init SQL-->".$sql."<br/>"; }


if (isset($_POST["name"])) {
  if($_POST["name"] !== ''){
    $x=mb_strtolower($_POST["name"], 'UTF-8');
    $x=addslashes($x);
    $sql .= " and name LIKE '%$x%'";
    if($debug == "1"){ echo "name=".$x."<br/>SQL-->".$sql."<br/>"; }
  }
}


if (isset($_POST["type_content"])) {
  if($_POST["type_content"] !== 'all'){
    $x=$_POST["type_content"];
    $sql .= " and type='$x'";
    if($debug == "1"){ echo "type_content=".$x."<br/>SQL-->".$sql."<br/>"; }
  }
}


if (isset($_POST["genre"])) {
  if($_POST["genre"] !== ''){
    $x=mb_strtolower($_POST["genre"], 'UTF-8');
    switch ($x) {
      case "бойовик/екшн": $sql .= " AND (genres LIKE '%екшн%' OR genres LIKE '%бойовик%')"; break;
      case "фантастика": $sql .= " AND genres LIKE '%фантасти%'"; break;
      case "пригоди": $sql .= " AND genres LIKE '%пригод%'"; break;
      case "вестерн": $sql .= " AND genres LIKE '%вестерн%'"; break;
      case "трилер": $sql .= " AND genres LIKE '%трилер%'"; break;
      case "містика": $sql .= " AND genres LIKE '%місти%'"; break;
      case "жахи": $sql .= " AND genres LIKE '%жахи%'"; break;
      case "детектив": $sql .= " AND genres LIKE '%детектив%'"; break;
      case "драма": $sql .= " AND genres LIKE '%драма%'"; break;
      case "кримінальний": $sql .= " AND genres LIKE '%кримінал%'"; break;
      case "військовий/воєнний": $sql .= " AND (genres LIKE '%військовий%' OR genres LIKE '%воєнний%')"; break;
      case "сімейний": $sql .= " AND genres LIKE '%сімейний%'"; break;
      case "комедія": $sql .= " AND genres LIKE '%комеді%'"; break;
      case "фентезі": $sql .= " AND genres LIKE '%фентезі%'"; break;
      case "мелодрама/романтика": $sql .= " AND (genres LIKE '%романти%' OR genres LIKE '%мелодрама%')"; break;
      case "еротика": $sql .= " AND genres LIKE '%ероти%'"; break;
      case "історичний": $sql .= " AND genres LIKE '%істор%'"; break;
      case "біографічний": $sql .= " AND genres LIKE '%біографі%'"; break;
      case "спорт": $sql .= " AND genres LIKE '%спорт%'"; break;
      case "музичний/мюзикл": $sql .= " AND (genres LIKE '%мюзикл%' OR genres LIKE '%музичний%')"; break;
      case "документальний/науковий": $sql .= " AND (genres LIKE '%документ%' OR genres LIKE '%наук%')"; break;
    }
    if($debug == "1"){ echo "genre=".$x."<br/>SQL-->".$sql."<br/>"; }
  }
 }


if (isset($_POST["year"])) {
  if($_POST["year"] !== 'всі'){
    $x=$_POST["year"];
    $sql .= " and year='$x'";
    if($debug == "1"){ echo "year=".$x."<br/>SQL-->".$sql."<br/>"; }
  }
}


if (isset($_POST["tracker"])) {
  if($_POST["tracker"] !== 'all'){
    $x=$_POST["tracker"];
    $sql .= " and tracker='$x'";
    if($debug == "1"){ echo "tracker=".$x."<br/>SQL-->".$sql."<br/>"; }
  }
}


if (isset($_POST["watch"])) {
  switch ($_POST["watch"]) {
    case "yes": $sql .= " and watched='1'"; break;
    case "no":  $sql .= " and watched='0'"; break;
  }	
  if($debug == "1"){ echo "watch: ".$_POST["watch"]." SQL-->".$sql."<br/>"; }
}


if (isset($_POST["watched"])) {
  switch ($_POST["watched"]) {
    case "bad": $sql .= " and watched='1' and myrating<'7'"; break;
    case "good":  $sql .= " and watched='1' and myrating>'6'"; break;
    case "verygood":  $sql .= " and watched='1' and myrating>'8'"; break;
  }	
  if($debug == "1"){ echo "watched: ".$_POST["watched"]." SQL-->".$sql."<br/>"; }
}


if(isset($_POST["zero_rate"])){
  $sql .= " and myrating='0'";
  if($debug == "1"){ echo "Zero rating --> On <br/>SQL-->".$sql."<br/>"; }
}


if(isset($_POST["have_files"])){
  $sql .= " AND `path`!=''";
  if($debug == "1"){ echo "Have Video Files --> On <br/>SQL-->".$sql."<br/>"; }
}


if (isset($_POST["IMDB_rate"])) {
  if($_POST["IMDB_rate"] !== ''){
    $x=$_POST["IMDB_rate"];
    $x=str_replace(',','.',$x);
    $sql .= " and `IMDB_rating`> '$x' ";
    if($debug == "1"){ echo "IMDB_rating=".$x."<br/>SQL-->".$sql."<br/>"; }
  }
}


if (isset($_POST["technical"])) {
  if($_POST["technical"] !== ''){
    switch ($_POST["technical"]) {
      case "no_IMDB_rated": $sql .= " AND `IMDB_rated`='0'"; break;
      case "no_story": $sql .= " AND `story`=''"; break;
    }	
#    $sql .= " and `IMDB_rated`='0'";
    $need_limit = '1';
  }
}


$last = substr($sql, -7);
if ( substr($sql, -7) == "where 1" ) {
    echo "<br/><br/>Вивід повної бази не дозволено!<br/>";
    goto TheEnd;
}


if (isset($_POST["sort"])) {
  switch ($_POST["sort"]) {
    case "aya": $sql .= " ORDER BY `name` ASC"; break;
    case "yaa": $sql .= " ORDER BY `name` DESC"; break;
  }	
  if($debug == "1"){ echo "SORT=".$_POST['sort']."<br/>SQL-->".$sql."<br/>"; }
}


if ( $need_limit ) { $sql .= " LIMIT 100;"; } else { $sql .= " LIMIT 1000;"; }
  $sql_count = str_replace( "`name`,`year`,`codec`,`resolution`,`watched`,`myrating`,`IMDB_rating`,`IMDB_voices`,`IMDB_link`,`IMDB_rated`,`tracker`,`tracker_link`,`path`,`genres`,`story`", "count(*)", $sql );
  if($debug == "1"){ echo "<br/>Last SQL-->".$sql."<br/><br/>"; }
  $result = mysqli_query( $link, $sql_count );
  $num = mysqli_fetch_all($result, MYSQLI_NUM);
  $result = mysqli_query( $link, $sql );
  $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);

  echo '<p style="margin-left: 250px;">  <input type="button" onclick="history.back();" value="Назад"/>';
  echo '&emsp;&emsp;&emsp;' . '<input type="button" onclick="history.go(0);" value="Оновити сторінку"/>  </p>';

if ( $num[0][0] <= 1000 ) {
   echo "Всього результатів:  ".$num[0][0];
} else {
  echo "Показано результатів: 1000. Всього: ".$num[0][0];
}
?>

<?php
require __DIR__ . '/show_table.php';
?>

<?php
  mysqli_free_result($result);

TheEnd:
  echo '<p style="margin-left: 250px;">  <input type="button" onclick="history.back();" value="Назад"/>';
  echo '&emsp;&emsp;&emsp;' . '<input type="button" onclick="history.go(0);" value="Оновити сторінку"/>  </p>';
  
  mysqli_close($link);
?>
</body>
</html>
