$(function(){
    $('#button').click(function(){ 
        if(!$('#iframe').length) {
                $('#iframeHolder').html('<iframe id="iframe" src="includes/db_stats.php" name="db_stats" scrolling="auto" width="500px" height="300px" style="border: 1px solid #000000;"></iframe>');
        }
    });   
});

$(function(){
    $("input[type='radio'][name='watch']").change(function() {
        if ($('#no').is(':checked')) {
            $('#all2').prop("checked", true);
        }
    });
});

function AnswerNo() {
    document.getElementById("bad").disabled = true;
    document.getElementById("good").disabled = true;
    document.getElementById("verygood").disabled = true;
}

function AnswerOther() {
    document.getElementById("bad").disabled = false;
    document.getElementById("good").disabled = false;
    document.getElementById("verygood").disabled = false;
}
