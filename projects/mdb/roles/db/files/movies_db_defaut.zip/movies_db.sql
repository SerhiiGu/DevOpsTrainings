/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.13-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: movies_db
-- ------------------------------------------------------
-- Server version	10.11.13-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `movies_db`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `movies_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `movies_db`;

--
-- Table structure for table `duplicates`
--

DROP TABLE IF EXISTS `duplicates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `duplicates` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(192) NOT NULL,
  `year` int(11) NOT NULL,
  `codec` varchar(8) NOT NULL,
  `resolution` varchar(16) NOT NULL,
  `type` enum('film','cartoon','serial','documental') NOT NULL,
  `path` varchar(1024) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=545 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `forums_toloka`
--

DROP TABLE IF EXISTS `forums_toloka`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `forums_toloka` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `forum_uri` varchar(255) NOT NULL,
  `forum_name` varchar(255) NOT NULL,
  `last_scan_date` date NOT NULL DEFAULT curdate(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `forum_uri` (`forum_uri`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `movies`
--

DROP TABLE IF EXISTS `movies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `movies` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(320) NOT NULL,
  `year` smallint(6) NOT NULL,
  `type` enum('film','cartoon','serial','documental') NOT NULL,
  `watched` tinyint(1) NOT NULL,
  `myrating` tinyint(4) NOT NULL,
  `IMDB_rating` float NOT NULL,
  `IMDB_voices` int(11) NOT NULL,
  `IMDB_link` varchar(96) NOT NULL,
  `IMDB_rated` tinyint(1) NOT NULL DEFAULT 0,
  `filmcompanies` varchar(192) NOT NULL,
  `genres` varchar(256) NOT NULL,
  `directors` varchar(256) NOT NULL,
  `actors` varchar(2048) NOT NULL,
  `story` varchar(4096) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=21294 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `movies_files`
--

DROP TABLE IF EXISTS `movies_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `movies_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `movie_no` int(11) NOT NULL,
  `codec` varchar(8) NOT NULL,
  `resolution` varchar(16) NOT NULL,
  `tracker` enum('none','Hurtom','Utopia') NOT NULL DEFAULT 'none',
  `tracker_link` varchar(96) NOT NULL,
  `path` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `movie_no_idx` (`movie_no`),
  CONSTRAINT `fk_movies_files_movie_no` FOREIGN KEY (`movie_no`) REFERENCES `movies` (`no`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32768 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `serial_episodes`
--

DROP TABLE IF EXISTS `serial_episodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `serial_episodes` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `movie_no` int(11) NOT NULL,
  `start_year` smallint(6) DEFAULT NULL,
  `end_year` smallint(6) DEFAULT NULL,
  `episodes` smallint(5) unsigned DEFAULT NULL,
  `finished` enum('finished','ongoing') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `season` tinyint(3) unsigned DEFAULT NULL,
  `episode` smallint(5) unsigned DEFAULT NULL,
  `myrating` tinyint(3) unsigned DEFAULT NULL,
  `IMDB_rated` tinyint(1) unsigned DEFAULT NULL,
  PRIMARY KEY (`no`),
  UNIQUE KEY `movie_no` (`movie_no`,`season`,`episode`),
  CONSTRAINT `serial_episodes_ibfk_1` FOREIGN KEY (`movie_no`) REFERENCES `movies` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=171079 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topics_toloka`
--

DROP TABLE IF EXISTS `topics_toloka`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `topics_toloka` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `forum_uri` varchar(255) NOT NULL,
  `topic_url` varchar(1024) NOT NULL,
  `date_update` date NOT NULL DEFAULT curdate(),
  `imdb_url` varchar(1024) DEFAULT NULL,
  `present_in_db` enum('yes','no') NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`),
  UNIQUE KEY `topic_url` (`topic_url`) USING HASH,
  KEY `fk_topics_forum_uri` (`forum_uri`),
  CONSTRAINT `fk_topics_forum_uri` FOREIGN KEY (`forum_uri`) REFERENCES `forums_toloka` (`forum_uri`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=65972 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-02 17:30:59
