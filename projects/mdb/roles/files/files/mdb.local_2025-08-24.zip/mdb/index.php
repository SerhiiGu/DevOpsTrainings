<!DOCTYPE html>
<html>
<head>
    <title>База даних фільмів</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <style type="text/css">
        table{
             border:5px solid black; 
             margin-top:50px
        }
        td,tr{
            border:5px solid black;
        }
    </style>

  <script type="text/javascript" src="/js/jquery.min.js"></script>
	<script type="text/javascript" src="/js/script.js" defer></script>
</head>
<body>
<form action="includes/select.php" method="POST">
<br/> Назва (укр. /eng.) --  
    <input type="text" size="32" name="name">
<div> Тип контенту (фільм, мульт і т.д.) -- 
    <select name="type_content" id="type_content">
      <option value="all">all</option>
      <option value="film">film</option>
      <option value="cartoon">cartoon</option>
      <option value="serial">serial</option>
      <option value="documental">documental</option>
    </select>
</div>
<div id="finished_block" style="display:none;">
  <fieldset style="width:450px; padding:5px; margin:0;"> <b style='color:red'>Завершеність:&nbsp;&nbsp;&nbsp;&nbsp;</b>
    <label><input type="radio" name="finished_status" value="all" checked> Все</label>
    <label><input type="radio" name="finished_status" value="ongoing"> Не завершено</label>
    <label><input type="radio" name="finished_status" value="finished"> Завершено</label>
  </fieldset>
</div>  
Жанр -- 
    <?php
      $genres = array("всі","бойовик/екшн","фантастика","пригоди","вестерн","трилер","містика","жахи","детектив","драма","кримінальний","військовий/воєнний","сімейний","комедія","фентезі","мелодрама/романтика","еротика","історичний","біографічний","спорт","музичний/мюзикл","документальний/науковий");
    ?>
    <select name="genre">
        <?php
        foreach ($genres as $genre) {
            ?><option value="<?=$genre?>"><?=$genre?></option><?php
        }
        ?>
    </select>
<br/> Рік виходу --  <?php   require __DIR__ . '/includes/year.php'; ?>
<br/> Вибір трекера --
    <?php
      $trackers = array("all","Hurtom","Utopia");
    ?>
    <select name="tracker">
        <?php
        foreach ($trackers as $tracker) {
            ?><option value="<?=$tracker?>"><?=$tracker?></option><?php
        }
        ?>
    </select>

<fieldset style='width:400px'> <b style='color:red'>Переглядав?&nbsp;&nbsp;&nbsp;&nbsp;</b>
  <input type="radio" id="all" name="watch" value="all" onchange="AnswerOther()" checked />
  <label for="all">Не важливо</label>
  &nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" id="yes" name="watch" value="yes" onchange="AnswerOther()" />
  <label for="yes">Так</label>
  &nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" id="no" name="watch" value="no" onchange="AnswerNo()" />
  <label for="no">Ні</label>
</fieldset>

<fieldset style='width:700px'> <b style='color:red'>Переглянуте-оцінене</b>
  <input type="radio" id="all2" name="watched" value="all2" checked />
  <label for="all2">Все</label>
  &nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" id="bad" name="watched" value="bad" />
  <label for="bad">Погано(1-6)</label>
  &nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" id="good" name="watched" value="good" />
  <label for="good">Добре/чудово(7-10)</label>
    &nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" id="verygood" name="watched" value="verygood" />
  <label for="verygood">Чудово(9-10)</label>
</fieldset>

      Нульовий рейтинг  
    <input type="checkbox" name="zero_rate" />
<br>  Наявні відеофайли
    <input type="checkbox" name="have_files" />
<br/> Рейтинг IMDB вище(н-д: 8.5)
    <input type="text" size="5" name="IMDB_rate">
<br/> <br/>


<td>
<div id="spoiler"><div><input type="button" value="Технічні запити" style="width:150px;font-size:12px;margin:2px;padding:0px;" onclick="if (this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display != '') { this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display = ''; this.parentNode.parentNode.getElementsByTagName('div')['hide'].style.display = 'none'; this.innerText = ''; this.value = 'Сховати'; } else { this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display = 'none'; this.parentNode.parentNode.getElementsByTagName('div')['hide'].style.display = ''; this.innerText = ''; this.value = 'Технічні запити'; }" />
<div id="show" style="display: none; background-color:transparent; margin: 0px;border-style:solid;border-width:1px; font-size:14px; padding: 4px; width:95%">
  <fieldset>
    <div>
    <input type="radio" id="no_IMDB_rated" name="technical" value="no_IMDB_rated" />
    <label for="no_IMDB_rated">Не виставлений рейтинг IMDB</label>
    <br/><input type="radio" id="no_story" name="technical" value="no_story" />
    <label for="no_story">Фільми з незаповненим сюжетом</label>
    <br/><input type="radio" id="not_completed_series" name="technical" value="not_completed_series" />
    <label for="not_completed_series">Не повністю оброблені завершені серіали</label>
    <br/><input type="radio" id="choose_nothing" name="technical" value="choose_nothing" checked />
    <label for="choose_nothing">Нічого</label>    
    </div>
  </fieldset>
</div>
<div id="hide"></div></div></div>
</td>


<br/> 
<fieldset style='width:400px'> <b style='color:red'>Порядок сортування:&nbsp;&nbsp;&nbsp;&nbsp;</b>
  <input type="radio" id="aya" name="sort" value="aya" checked />
  <label for="aya">А-Я</label>
  &nbsp;&nbsp;&nbsp;&nbsp;
  <input type="radio" id="yaa" name="sort" value="yaa" />
  <label for="yaa">Я-А</label>
</fieldset>
<br/>


<p style="margin-left: 150px;">    <input type="submit" name="C" value="ok"> </p>
</form>

    <br/> <br/>
<form action="/" method="POST">
  <p style="margin-left: 110px;">    <input type="submit" name="X" value="очистити форму"> </p>
</form>


<br/> <br/> <br/> <br/>


<button><a href="filmography.php" class="button-class">Фільмографія акторів/режисерів</a></button>
<br/><br/>
<button id="button">Статистика бази даних</button>
<div id="iframeHolder"></div>


</body>
</html>
