<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Incorrect method.");
}
if (!isset($_POST['no'])) {
    die("Didn't set proper data.");
}
if (!is_numeric($_POST['no'])) {
    die("Incorrect data type.");
}

require __DIR__ . '/includes/mysql_config.php';
require __DIR__ . '/includes/functions.php';

$link = mysqli_connect($m_server, $m_user, $m_password, $m_database);
if ($link === false) {
    die("MySQL connect error: " . mysqli_connect_error());
}
mysqli_set_charset($link, "utf8mb4");

$movie_no = intval($_POST['no']);

// === Get serial main info ===
$sql = "
SELECT 
    m.name,
    se.finished,
    se.start_year,
    se.end_year,
    se.total_episodes,
    se.counted_episodes
FROM 
    movies m
LEFT JOIN (
    SELECT 
        movie_no,
        MAX(finished) AS finished,
        MIN(start_year) AS start_year,
        MAX(end_year) AS end_year,
        MAX(episodes) AS total_episodes,
        COUNT(*) AS counted_episodes
    FROM serial_episodes
    WHERE movie_no = ?
    GROUP BY movie_no
) se ON m.no = se.movie_no
WHERE m.no = ? AND m.type IN ('serial', 'documental')
";

$stmt = mysqli_prepare($link, $sql);
mysqli_stmt_bind_param($stmt, "ii", $movie_no, $movie_no);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$info = mysqli_fetch_assoc($result);
mysqli_free_result($result);
mysqli_stmt_close($stmt);

if (!$info) {
    die("No such serial.");
}

// === Year range formatting ===
$year_str = '';
if (!is_null($info['start_year'])) {
    if ($info['start_year'] === $info['end_year'] || is_null($info['end_year'])) {
        $year_str = $info['start_year'];
    } else {
        $year_str = $info['start_year'] . '-' . $info['end_year'];
    }
}
if ($info['finished'] !== 'finished') {
    $year_str = rtrim($year_str, '-' . $info['end_year']) . '-';
}

// === Display main info ===
echo "<h2>" . htmlspecialchars($info['name']) . "</h2>";
echo "<p><strong>ID:</strong> " . htmlspecialchars($movie_no) . "&emsp;&emsp;<strong>Status:</strong> " . htmlspecialchars($info['finished']) . "&emsp;&emsp;<strong>Years:</strong> " . htmlspecialchars($year_str) . "</p>";
echo "<p><strong>Total episodes (declared):</strong> " . (int)$info['total_episodes'] . "</p>";
echo "<p><strong>Total episodes (counted):</strong> " . (int)$info['counted_episodes'] . "</p>";

// === Get all series episodes ===
$episodes_sql = "
SELECT season, episode, myrating
FROM serial_episodes
WHERE movie_no = ? AND season IS NOT NULL AND episode IS NOT NULL
";
$stmt = mysqli_prepare($link, $episodes_sql);
mysqli_stmt_bind_param($stmt, "i", $movie_no);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// === Process episodes ===
$matrix = [];
$episode_numbers = [];

while ($ep = mysqli_fetch_assoc($result)) {
    $s = (int)$ep['season'];
    $e = (int)$ep['episode'];
    $matrix[$s][$e] = is_null($ep['myrating']) ? '' : $ep['myrating'];
    $episode_numbers[$e] = true;
}
mysqli_free_result($result);
mysqli_stmt_close($stmt);

// === Determine seasons and episodes ===
$seasons = array_keys($matrix);
sort($seasons, SORT_NUMERIC);

$episodes_all = array_keys($episode_numbers);
sort($episodes_all, SORT_NUMERIC);

// === Build the table ===
echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";

// Header row: E1, E2, ..., Total episodes
echo "<tr><th>Season \\ Episode</th>";
foreach ($episodes_all as $e) {
    echo "<th>E" . $e . "</th>";
}
echo "<th><strong>Total episodes</strong></th>";
echo "</tr>";

// Rows per season
foreach ($seasons as $s) {
    echo "<tr><td style='text-align:center;'><strong>S" . $s . "</strong></td>";
    $count = 0;
    foreach ($episodes_all as $e) {
        $val = isset($matrix[$s][$e]) ? htmlspecialchars($matrix[$s][$e]) : '';
        if ($val !== '') $count++;
        echo "<td style='text-align:center;'>$val</td>";
    }
    echo "<td style='text-align:center;'><strong>$count</strong></td>";
    echo "</tr>";
}
echo "</table><br/><br/>";

// Hidden form for repeat POST (for refresh page without confirmation)
echo "<form id='refreshForm' action='" . htmlspecialchars($_SERVER['PHP_SELF']) . "' method='post' style='display:none;'>";
echo "<input type='hidden' name='no' value='" . $movie_no . "'>";
echo "</form>";

$mainUrl = '/index.php';
echo '<p style="margin-left: 200px;">';
echo '<input type="button" onclick="history.back();" value="Назад"/> &emsp;&emsp;&emsp;';
echo '<input type="button" value="Оновити сторінку" onclick="document.getElementById(\'refreshForm\').submit();"/> &emsp;&emsp;&emsp;';
echo '<input type="button" onclick="window.location.href=\'' . $mainUrl . '\';" value="На головну"/>';
echo '</p>';

mysqli_close($link);
?>