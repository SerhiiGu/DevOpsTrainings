$(function(){
    $('#button').click(function(){ 
        if(!$('#iframe').length) {
                $('#iframeHolder').html('<iframe id="iframe" src="includes/db_stats.php" name="db_stats" scrolling="auto" width="600px" height="300px" style="border: 1px solid #000000;"></iframe>');
        }
    });   
});

$(function(){
    $("input[type='radio'][name='watch']").change(function() {
        if ($('#no').is(':checked')) {
            $('#all2').prop("checked", true);
        }
    });
});

function AnswerNo() {
    document.getElementById("bad").disabled = true;
    document.getElementById("good").disabled = true;
    document.getElementById("verygood").disabled = true;
}

function AnswerOther() {
    document.getElementById("bad").disabled = false;
    document.getElementById("good").disabled = false;
    document.getElementById("verygood").disabled = false;
}

function updateFinishedBlock() {
    var $select = $('#type_content');
    var $block  = $('#finished_block');
    if ($select.length === 0 || $block.length === 0) return;

    var val = String($select.val() || '').trim().toLowerCase();
    var shouldShow = (val === 'serial' || val === 'documental');

    if (shouldShow) {
        $block.show();
        $block.find('input[name="finished_status"]').prop('disabled', false);
    } else {
        $block.hide();
        $block.find('input[name="finished_status"][value="all"]').prop('checked', true);
        $block.find('input[name="finished_status"]').prop('disabled', true);
    }
}

$(function(){
    $('#type_content').on('change.finishedToggle', updateFinishedBlock);
    updateFinishedBlock();
});
