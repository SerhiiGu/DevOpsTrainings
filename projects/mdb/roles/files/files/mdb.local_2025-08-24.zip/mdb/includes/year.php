<?php

if (preg_match('/' . preg_quote($_SERVER['PHP_SELF'], '/') . '$/i', str_replace('\\', '/', __FILE__))) {
  exit('No direct script access allowed.');
}

  require __DIR__ . '/mysql_config.php';
  $link = mysqli_connect( $m_server, $m_user, $m_password, $m_database );
  if ($link == false){
    print("error: " . mysqli_connect_error());
    die;
  }

  mysqli_set_charset($link, "utf8mb4");
  $sql = "SELECT DISTINCT `year` FROM `movies` ORDER BY `year` DESC;";
  $result = mysqli_query( $link, $sql );
  $years = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<select name="year">
  <option value="всі">всі</option>
  <?php
    foreach ($years as $year) {
      ?><option value="<?=$year["year"]?>"><?=$year["year"]?></option><?php
    }
  ?>
</select>

<?php
mysqli_free_result($result);
mysqli_close($link);

?>

