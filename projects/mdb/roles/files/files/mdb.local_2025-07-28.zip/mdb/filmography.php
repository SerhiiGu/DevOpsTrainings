<!DOCTYPE html>
<html>
<head>
  <title>Фільмографія акторів/режисерів</title>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <style type="text/css">
    table{
      border:5px solid black; 
      margin-top:50px
    }
    td,tr{
      border:5px solid black;
    }
  </style>

  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/script.js"></script>
</head>
<body>
  <form action="includes/filmography_select.php" method="POST">
    <br/> Популярні режисери --  <?php   require __DIR__ . '/includes/directors.php'; ?>
    &emsp;&emsp;&emsp; або &emsp;&emsp;&emsp; 
    Пошук по режисеру -- <input type="text" size="24" name="txt_director">

    <br/><br/>або<br/>
    
    <br/> Популярні актори --  <?php   require __DIR__ . '/includes/actors.php'; ?>
    &emsp;&emsp;&emsp; або &emsp;&emsp;&emsp; 
    Пошук по актору --  <input type="text" size="24" name="txt_actor">

    <br/><br/><br/>
    <p style="margin-left: 150px;">    <input type="submit" name="C" value="ok"> </p>
  </form>

  <br/><br/><br/>
  <form action="/filmography.php" method="POST">
    <p style="margin-left: 110px;">    <input type="submit" name="X" value="очистити форму"> </p>
  </form>

  <br/><br/><br/><br/><br/>
  &emsp;&emsp;&emsp;&emsp;&emsp;&emsp; <button><a href="index.php" class="button-class">Назад на головну</a></button>
</body>
</html>
