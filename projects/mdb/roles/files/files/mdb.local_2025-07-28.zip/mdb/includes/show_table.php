<script>
$(document).ready( function () {
    $('#myTable').DataTable({
      aLengthMenu: [15,50,100,500],
    });
});
</script>

<?php
  echo "<table id='myTable' class='stripe'>
  <thead>
  <tr>
  <th>Назва</th>
  <th>Рік</th>
  <th style='font-size:12px'>Кодек</th>
  <th>Якість</th>
  <th style='font-size:10px'>Переглядав?</th>
  <th>Жанри</th>
  <th style='font-size:12px'>МійРейт</th>
  <th style='font-size:12px'>IMDB</th>
  <th style='font-size:12px'>Голосів</th>
  <th style='font-size:10px'>IMDB link</th>
  <th style='font-size:10px'>Tracker</th>
  <th style='font-size:10px'>Tracker link</th>
  <th>Шлях</th>
  <th style='font-size:12px'>Сюжет</th>
  </tr>
  </thead>
  <tbody>";

  $safe_rows = unserialize(serialize($rows)); //deep copy because of reference is somewhere

  foreach ($safe_rows as $row) {
    echo "<tr>";
    echo "<td class='name'>" . $row['name'] . "</td>";
    echo "<td style='font-size:14px'>" . $row['year'] . "</td>";
    echo "<td style='font-size:10px'>" . $row['codec'] . "</td>";
    echo "<td style='font-size:10px'>" . $row['resolution'] . "</td>";
    if($row['watched']==1){ echo "<td style='color:green;font-size:10px'>&emsp;Так</td>"; } else { echo "<td style='color:red;font-size:10px'>&emsp;Ні</td>"; };
    echo "<td class='genres'>" . $row['genres'] . "</td>";
    echo "<td style='font-size:14px'>" . $row['myrating'] . "</td>";
    echo "<td style='font-size:14px'>" . $row['IMDB_rating'] . "</td>";
    echo "<td style='font-size:10px'>" . $row['IMDB_voices'] . "</td>";
    $array = explode( "/", $row['IMDB_link'] );
    $topic = '';
    if (str_contains($array[count($array) -1], 'tt' )){
      $topic = $array[count($array) -1];
    } elseif (str_contains($array[count($array) -2], 'tt' )){
      $topic = $array[count($array) -2];
    }
    echo "<td style='font-size:10px'><a href=" . $row['IMDB_link'] . " rel='noopener noreferrer' target='_blank'> " . $topic . "</a></td>";
    echo "<td style='font-size:10px'>" . $row['tracker'] . "</td>";
    $array = explode( "/", $row['tracker_link'] );
    $topic = $array[count($array) -1];
    echo "<td style='font-size:10px'><a href=" . $row['tracker_link'] . " rel='noopener noreferrer' target='_blank'> " . $topic . "</a></td>";	

    if( ($row['path'] == "" || $row['path'] == "-") && $row['watched'] == 1 && $row['myrating'] > 0 && $row['myrating'] < 7 ){
      echo "<td style='font-size:10px'>--bad--</td>";
    } elseif ( ($row['path'] == "" || $row['path'] == "-") && $row['watched'] == 1 && $row['myrating'] > 6 ){
      echo "<td style='font-size:14px'>NO FILE</td>";
    } elseif ( ($row['path'] == "" || $row['path'] == "-") && $row['watched'] == 1 && $row['myrating'] == 0 ) {
      echo "<td style='font-size:10px'>--not watched--</td>";
    } elseif ( $row['path']) {
?>
    <td>
    <div id="spoiler"><div><input type="button" value="Показати" style="width:70px;font-size:12px;margin:2px;padding:0px;" onclick="if (this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display != '') { this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display = ''; this.parentNode.parentNode.getElementsByTagName('div')['hide'].style.display = 'none'; this.innerText = ''; this.value = 'Сховати'; } else { this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display = 'none'; this.parentNode.parentNode.getElementsByTagName('div')['hide'].style.display = ''; this.innerText = ''; this.value = 'Показати'; }" />
    <div id="show" style="display: none; background-color:transparent; margin: 0px;border-style:solid;border-width:1px; font-size:10px; padding: 4px; width:200px"><?php echo $row['path'];?></div>
    <div id="hide"></div></div></div>
    </td>
<?php
    } else {
      echo "<td style='font-size:14px'>NO FILE</td>";
    } 
if( $row['story'] ){
?>
    <td>
    <div id="spoiler"><div><input type="button" value="Показати" style="width:70px;font-size:12px;margin:2px;padding:0px;" onclick="if (this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display != '') { this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display = ''; this.parentNode.parentNode.getElementsByTagName('div')['hide'].style.display = 'none'; this.innerText = ''; this.value = 'Сховати'; } else { this.parentNode.parentNode.getElementsByTagName('div')['show'].style.display = 'none'; this.parentNode.parentNode.getElementsByTagName('div')['hide'].style.display = ''; this.innerText = ''; this.value = 'Показати'; }" />
    <div id="show" style="display: none; background-color:transparent; margin: 0px;border-style:solid;border-width:1px; font-size:12px; padding: 4px; width:400px"><?php echo $row['story'];?></div>
    <div id="hide"></div></div></div>
    </td>
<?php  }   ?>

<?php
    echo "</tr>";
  }
    echo "</tbody> </table>";
?>
