<?php

if (preg_match('/' . preg_quote($_SERVER['PHP_SELF'], '/') . '$/i', str_replace('\\', '/', __FILE__))) {
  exit('No direct script access allowed.');
}

$m_server = "mysql";
$m_user = "root";
$m_password = "root";
$m_database = "movies_db";
$debug = 0;
