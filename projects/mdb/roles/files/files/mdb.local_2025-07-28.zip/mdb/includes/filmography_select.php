<!DOCTYPE html>
<html>
<head>
  <script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="../js/script.js"></script>
  <link rel="stylesheet" type="text/css" href="../js/datatables.min.css"/>
  <script type="text/javascript" src="../js/datatables.min.js"></script>
</head>
<body>
<?php
  require __DIR__ . '/mysql_config.php';
  require __DIR__ . '/functions.php';
?>

<style type="text/css">
  <?php include __DIR__ . '/style.css'; ?>
</style>

<?php
  $link = mysqli_connect( $m_server, $m_user, $m_password, $m_database );
  if ($link == false){
    print("error: " . mysqli_connect_error());
    die;
  }

  mysqli_set_charset($link, "utf8mb4");
  
  $sql = "select `name`,`year`,`watched`,`myrating`,`IMDB_rating`,`IMDB_voices`,`IMDB_link`,`IMDB_rated`,`tracker`,`tracker_link`,`path`,`genres`,`directors`,`actors`,`story` from `movies` where 1";
  if($debug == "1"){ echo "Init SQL-->".$sql."<br/>"; }

  if (isset($_POST["director"])) {
    if($_POST["director"] !== 'all'){
      $x=$_POST["director"];
      $sql .= " and directors LIKE '%$x%'";
      if($debug == "1"){ echo "director=".$x."<br/>SQL-->".$sql."<br/>"; }
      goto ShowTable;
    }
  }

  if (isset($_POST["txt_director"])) {
    if($_POST["txt_director"] !== ''){
      $x=mb_strtolower($_POST["txt_director"], 'UTF-8');
      $x=addslashes($x);
      $sql .= " and directors LIKE '%$x%'";
      if($debug == "1"){ echo "txt_director=".$x."<br/>SQL-->".$sql."<br/>"; }
      goto ShowTable;
    }
  }

  if (isset($_POST["actor"])) {
    if($_POST["actor"] !== 'all'){
      $x=$_POST["actor"];
      $sql .= " and actors LIKE '%$x%'";
      if($debug == "1"){ echo "actor=".$x."<br/>SQL-->".$sql."<br/>"; }
      goto ShowTable;
    }
  }

  if (isset($_POST["txt_actor"])) {
    if($_POST["txt_actor"] !== ''){
      $x=mb_strtolower($_POST["txt_actor"], 'UTF-8');
      $x=addslashes($x);
      $sql .= " and actors LIKE '%$x%'";
      if($debug == "1"){ echo "txt_actor=".$x."<br/>SQL-->".$sql."<br/>"; }
      goto ShowTable;
    }
  }

  echo "<br/><br/>Вивід повної бази не дозволено!<br/>";
  goto TheEnd;

ShowTable:
  $sql_count = str_replace( "`name`,`year`,`watched`,`myrating`,`IMDB_rating`,`IMDB_voices`,`IMDB_link`,`IMDB_rated`,`tracker`,`tracker_link`,`path`,`genres`,`directors`,`actors`,`story`", "count(*)", $sql );
  if($debug == "1"){ echo "<br/>Last SQL-->".$sql."<br/><br/>"; }
  $result = mysqli_query( $link, $sql_count );
  $num = mysqli_fetch_all($result, MYSQLI_NUM);
  $result = mysqli_query( $link, $sql );
  $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);

  echo '<p style="margin-left: 250px;">  <input type="button" onclick="history.back();" value="Назад"/>';
  echo '&emsp;&emsp;&emsp;' . '<input type="button" onclick="history.go(0);" value="Оновити сторінку"/>  </p>';

  echo "Всього результатів:  ".$num[0][0];
?>


 <?php
    require __DIR__ . '/show_table_filmography.php';
?>
  
<?php
  mysqli_free_result($result);
  
TheEnd:
  echo '<p style="margin-left: 250px;">  <input type="button" onclick="history.back();" value="Назад"/>';
  echo '&emsp;&emsp;&emsp;' . '<input type="button" onclick="history.go(0);" value="Оновити сторінку"/>  </p>';
    
  mysqli_close($link);
?>
</body>
</html>
  
