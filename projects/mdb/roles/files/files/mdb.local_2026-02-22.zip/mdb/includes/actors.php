<?php

// if (preg_match('/' . preg_quote($_SERVER['PHP_SELF'], '/') . '$/i', str_replace('\\', '/', __FILE__))) {
//   exit('No direct script access allowed.');
// }

  require __DIR__ . '/mysql_config.php';
  $link = mysqli_connect( $m_server, $m_user, $m_password, $m_database );
  if ($link == false){
    print("error: " . mysqli_connect_error());
    die;
  }

  mysqli_set_charset($link, "utf8mb4");

  $sql = "SHOW TABLES LIKE 'actors_directors';";
  $result = mysqli_query( $link, $sql );
  $num = mysqli_fetch_all($result, MYSQLI_NUM);
  if ( $num[0][0] == 0 ) { goto TheEnd; }

  $sql = "SELECT DISTINCT `name` FROM `actors_directors` where `role`='actor' ORDER BY `name` ASC;";
  $result = mysqli_query( $link, $sql );
  $actors = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<select name="actor">
  <option value="all">всі популярні</option>
  <?php
    foreach ($actors as $actor) {
      ?><option value="<?=$actor["name"]?>"><?=$actor["name"]?></option><?php
    }
  ?>
</select>

<?php
TheEnd:
  mysqli_free_result($result);
  mysqli_close($link);
?>
