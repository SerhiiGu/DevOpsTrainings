<?php
  
require __DIR__ . '/../includes/mysql_config.php';
require __DIR__ . '/../includes/functions.php';

$link = mysqli_connect( $m_server, $m_user, $m_password, $m_database );
if ( $link == false ){
  print("error: " . mysqli_connect_error());
  die;
}

mysqli_set_charset($link, "utf8mb4");

### Creating table if not exist
$sql = "CREATE TABLE IF NOT EXISTS `actors_directors`(
  `role` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `movies` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`role`, `name`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;";
$result = mysqli_query( $link, $sql );

###################################
##### Working with directors
### get all unique strings from table
$sql = "select distinct `directors` from `movies`;";
$result = mysqli_query( $link, $sql );
$rows = mysqli_fetch_all($result, MYSQLI_ASSOC);

### parse all strings
$directors_array = array();
foreach( $rows as $row ){
  ### parse result array row by row(can be more than one name in row)
  $directors =  explode(",", $row['directors']);
  foreach( $directors as $director ){
    ### can be '/', '()', '[]', '' delimiters in the string
    if( substr_count($director, "(") > 0 ){
      $x = explode("(", $director);
      $res = ltrim($x[1]);
      $x = explode(")", $res);
      $result = ltrim($x[0]);
    } elseif( substr_count($director, "[") > 0 ) {
      $x = explode("[", $director);
      $res = ltrim($x[1]);
      $x = explode("]", $res);
      $result = ltrim($x[0]);
    } elseif( substr_count($director, "/") > 0 ) {
      $x = explode("/", $director);
      $result = ltrim($x[1]);
    } else {
      $result = $director;
    }
    array_push($directors_array, $result);
  }
}

$directors_array = array_unique($directors_array);

### get the IDs of films where they were directors 
foreach( $directors_array as $name ){
  if(strlen(trim($name)) > 0){
    $name = addcslashes($name, "'");
    $sql = "select distinct `no` from `movies` where directors like '%$name%';";
    $result = mysqli_query( $link, $sql );
    $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
    $movies_from_sql = implode(',', array_map(function ($entry) {
        return ($entry[key($entry)]);
      }, $rows));
    $count_of_films = substr_count($movies_from_sql, ',');
    ### get only productive directors with 10+ films directed
    if( $count_of_films > 8 ){
      $sql = "SELECT * from `actors_directors` WHERE `role`='director' AND `name`='$name';";
      $result = mysqli_query( $link, $sql );
      $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
      $num = mysqli_affected_rows($link);
      if( $num == 1 ){
        if( $movies_from_sql != $rows[0]['movies'] ){
          $sql = "UPDATE `actors_directors` SET `movies`='$movies_from_sql' 
            WHERE `role`='director' AND `name`='$name';";
          $result = mysqli_query( $link, $sql );
          // echo "Update: role='director', name='$name', movies_from_sql='$movies_from_sql', ";
          // echo "movies_from_table='".$rows[0]['movies']."'\n";
        }
      }elseif( $num == 0 ){
        $sql = "INSERT INTO `actors_directors`(`role`,`name`,`movies`)
          VALUES('director', '$name', '$movies_from_sql');";
        $result = mysqli_query( $link, $sql );
        // echo "Insert: role='director', name='$name', movies_from_sql='$movies_from_sql' \n";
      }else{
        echo "Something gone wrong: role=director, name=$name, movies_from_table=$rows[0]['movies'], ";
        echo "movies_from_sql=$movies_from_sql, num=$num";
        print_r($rows);
      }
    }
  }
}

##################################
##### Working with actors
### get all unique strings from table
$sql = "select distinct `actors` from `movies`;";
$result = mysqli_query( $link, $sql );
$rows = mysqli_fetch_all($result, MYSQLI_ASSOC);

### parse all strings
$actors_array = array();
foreach( $rows as $row ){
  ### parse result array row by row(can be more than one name in row)
  $actors =  explode(",", $row['actors']);
  foreach( $actors as $actor ){
    ### can be '/', '()', '[]', '' delimiters in the string
    if( substr_count($actor, "(") > 0 ){
      $x = explode("(", $actor);
      $res = ltrim($x[1]);
      $x = explode(")", $res);
      $result = ltrim($x[0]);
    } elseif( substr_count($actor, "[") > 0 ) {
      $x = explode("[", $actor);
      $res = ltrim($x[1]);
      $x = explode("]", $res);
      $result = ltrim($x[0]);
    } elseif( substr_count($actor, "/") > 0 ) {
      $x = explode("/", $actor);
      $result = ltrim($x[1]);
    } else {
      $result = $actor;
    }
    array_push($actors_array, $result);
  }
}

$actors_array = array_unique($actors_array);

### get the IDs of films where they were actors 
foreach( $actors_array as $name ){
  if(strlen(trim($name)) > 0){
    $name = addcslashes($name, "'");
    $sql = "select distinct `no` from `movies` where actors like '%$name%';";
    $result = mysqli_query( $link, $sql );
    $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
    $movies_from_sql = implode(',', array_map(function ($entry) {
        return ($entry[key($entry)]);
      }, $rows));
    $count_of_films = substr_count($movies_from_sql, ',');
    ### get only productive actors with 10+ roles
    if( $count_of_films > 8 ){
      $sql = "SELECT * from `actors_directors` WHERE `role`='actor' AND `name`='$name';";
      $result = mysqli_query( $link, $sql );
      $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
      $num = mysqli_affected_rows($link);
      if( $num == 1 ){
        if( $movies_from_sql != $rows[0]['movies'] ){
          $sql = "UPDATE `actors_directors` SET `movies`='$movies_from_sql' 
            WHERE `role`='actor' AND `name`='$name';";
          $result = mysqli_query( $link, $sql );
          // echo "Update: role='actor', name='$name', movies_from_sql='$movies_from_sql', ";
          // echo "movies_from_table='".$rows[0]['movies']."'\n";
        }
      }elseif( $num == 0 ){
        $sql = "INSERT INTO `actors_directors`(`role`,`name`,`movies`)
          VALUES('actor', '$name', '$movies_from_sql');";
        $result = mysqli_query( $link, $sql );
        // echo "Insert: role='actor', name='$name', movies_from_sql='$movies_from_sql' \n";
      }else{
        echo "Something gone wrong: role=actor, name=$name, movies_from_table=$rows[0]['movies'], ";
        echo "movies_from_sql=$movies_from_sql, num=$num";
        print_r($rows);
      }
    }
  }
}


mysqli_close($link);
?>
